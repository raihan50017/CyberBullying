This package contains 3 files - one each of Hindi, Bangla and English. 

All the sets contain the IDs and the text in <ID,text> format.

You need to submit the labels for each of the two sub-tasks in separate files <ID,label> format on CodaLab. Further submission instructions will be made available on the CodaLab page.
